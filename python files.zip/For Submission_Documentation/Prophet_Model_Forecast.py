# %% [markdown]
# Filename: sample.py
# Author: Team5: Jan Pierre Lusterio, Lovely Cano, Nicanor Nuqui, Saisuraj Rajesh
# Course: Data_406_CapStone_Project
# Details: This program allows you to forecast GHG emissions for the next 'x' years, based on selected the sector, country, gas type, and granularity.
# NOTE: adjust the x variable to change the number of years ahead for the forecast.
# PRE-REQ: pip install pandas prophet matplotlib
# Resources: https://facebook.github.io/prophet/docs/quick_start.html#python-api
# 

# %%
# Loading Libraries
import pandas as pd
from prophet import Prophet
import matplotlib.pyplot as plt
import tqdm as notebook_tqdm

# %%
# Load the dataset provided by Power BI
# df = dataset # for powerbi loading..


# test load of dataset
file_path = "Emission_Dataset.xlsx"  # Load the Excel file

df = pd.read_excel(file_path) # Load the CSV into a DataFrame
df.head()

# %%
df.info()

# %%
# Convert the Year column to datetime format 
df['Year'] = pd.to_datetime(df['Year'], format='%Y')


# df['Year'] = pd.to_datetime(df['Year'])
# df['start_time'] = pd.to_datetime(df['start_time'])
# df.set_index('start_time', inplace=True)


# %%
# # Select the specific sector and country of interest based on filter selection

sector = 'power'  # replace with selected sector
gas = 'co2e_100yr'  # replace with selected gas
# country = 'China'  # replace with selected country
temporal_granularity = 'annual'  # replace with selected granularity (daily, weekly, monthly, annual)
iso3_country  = 'CHN'  # for this test purpose we use iso3_country

# Filter the dataset for the chosen sector, country, and granularity
# df_filtered = df[(df['sector'] == sector) & (df['iso3_country'] == iso3_country) & (df['gas'] == gas)]
df_filtered = df[(df['gas'] == gas)]

# %%
# Set Year as the index for resampling
df_filtered.set_index('Year', inplace=True)

# %%
# Resample the data to the desired granularity

if temporal_granularity == 'daily':
    df_resampled = df_filtered.resample('D').sum(numeric_only=True)
elif temporal_granularity == 'weekly':
    df_resampled = df_filtered.resample('W').sum(numeric_only=True)
elif temporal_granularity == 'monthly':
    df_resampled = df_filtered.resample('M').sum(numeric_only=True)
elif temporal_granularity == 'annual':
    df_resampled = df_filtered.resample('A').sum(numeric_only=True)




# %%
# Prepare data for Prophet
df_prophet = df_resampled.reset_index()[['Year', 'emissions_quantity']].rename(columns={'Year': 'ds', 'emissions_quantity': 'y'})

# %%
# Print the prepared DataFrame for Prophet
print(df_prophet.head())

# %%
# Create and fit the Prophet model
model = Prophet()
model.fit(df_prophet)

# %%
# Make future dataframe for x years ahead (replace x with desired number of years)
x = 10  # replace with user input for number of years
future = model.make_future_dataframe(periods=x, freq='Y')  # x years ahead

# %%
future

# %%
# Forecast the future emissions
forecast = model.predict(future)

# %%
# Print the forecast DataFrame
print(forecast[['ds', 'yhat']])

# %%
# Merge the forecast with the original data for output
df_forecast_merged = pd.merge(df_prophet, forecast[['ds', 'yhat']], on='ds', how='outer')

# Rename columns for clarity
df_forecast_merged.rename(columns={'yhat': 'forecasted_emissions'}, inplace=True)


# %%
# df_sector_country_forecast
df_forecast_merged

# %%
# Visualization using matplotlib
plt.figure(figsize=(12, 7))

# Plot the actual emissions
plt.plot(df_prophet['ds'], df_prophet['y'], label='Actual Emissions', marker='o', color='blue')

# Plot the forecasted emissions
plt.plot(df_forecast_merged['ds'], df_forecast_merged['forecasted_emissions'], label='Forecasted Emissions', linestyle='--', color='red')


# Adding text annotation for filters
filters_text = (f"Sector: {sector}\n"
                f"Country: {iso3_country}\n"
                f"Gas: {gas}\n"
                f"Temporal Granularity: {temporal_granularity}")

# Get axis limits
x_min, x_max = plt.xlim()
y_min, y_max = plt.ylim()

# Calculate the vertical center
y_center = (y_max + y_min) / 2.35

# Place text annotation at the bottom left
plt.text(x=x_min, y=y_center, s=filters_text, 
         fontsize=10, verticalalignment='bottom', horizontalalignment='left', 
         bbox=dict(boxstyle='round', facecolor='white', alpha=0.4))


plt.xlabel('Year')
plt.ylabel('Emissions (in Billion Tonnes)')
plt.title('GHG Emissions Forecast')
plt.legend()
plt.grid(True)
plt.show()

# %%
# Visualization using matplotlib
plt.figure(figsize=(10, 6))
plt.plot(df_forecast_merged['ds'], df_forecast_merged['y'], label='Actual Emissions')
plt.plot(df_forecast_merged['ds'], df_forecast_merged['forecasted_emissions'], label='Forecasted Emissions', linestyle='--')

# Adding text annotation for filters
filters_text = (f"Sector: {sector}\n"
                f"Country: {iso3_country}\n"
                f"Gas: {gas}\n"
                f"Temporal Granularity: {temporal_granularity}")

# Get axis limits
x_min, x_max = plt.xlim()
y_min, y_max = plt.ylim()

# Calculate the vertical center
y_center = (y_max + y_min) / 2.35

# Place text annotation at the bottom left
plt.text(x=x_min, y=y_center, s=filters_text, 
         fontsize=10, verticalalignment='bottom', horizontalalignment='left', 
         bbox=dict(boxstyle='round', facecolor='white', alpha=0.4))


plt.xlabel('Year')
plt.ylabel('Emissions (in Billion Tonnes)')
plt.title('GHG Emissions Forecast')
plt.legend()
plt.show()



