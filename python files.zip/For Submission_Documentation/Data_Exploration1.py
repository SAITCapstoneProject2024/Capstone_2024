# %%
# %%

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import chi2_contingency

# Load the Excel file
file_path = 'Emission_Dataset.xlsx'
emission_data = pd.read_excel(file_path)

# Retain only the specified columns
columns_to_keep = ['iso3_country', 'sector', 'subsector', 'gas', 'emissions_quantity', 'Year']
filtered_emission_data = emission_data[columns_to_keep]

# %%
# %%

# Descriptive Statistics
def descriptive_statistics(df):
    print("Descriptive Statistics:")
    
    # Summary statistics for emissions quantity
    print("\nSummary Statistics for Emissions Quantity:")
    print(df['emissions_quantity'].describe())
    
    # Summary statistics by Sector
    print("\nSummary Statistics by Sector:")
    print(df.groupby('sector')['emissions_quantity'].describe())
    
    # Summary statistics by Subsector
    print("\nSummary Statistics by Subsector:")
    print(df.groupby('subsector')['emissions_quantity'].describe())

# Data Visualization
def data_visualization(df):
    # Distribution of emissions quantity
    plt.figure(figsize=(12, 6))
    sns.histplot(df['emissions_quantity'], bins=20, kde=True)
    plt.title('Distribution of Emissions Quantity')
    plt.xlabel('Emissions Quantity')
    plt.ylabel('Frequency')
    plt.show()
    
    # Emissions over Years # visual legend is not over the plot
    # plt.figure(figsize=(12, 6))
    # sns.lineplot(data=df, x='Year', y='emissions_quantity', hue='iso3_country', marker='o')
    # plt.title('Emissions Quantity Over Years')
    # plt.xlabel('Year')
    # plt.ylabel('Emissions Quantity')
    # plt.legend(title='Country')
    # plt.show()
    
    # Emissions by Sector
    plt.figure(figsize=(12, 6))
    sns.boxplot(data=df, x='sector', y='emissions_quantity')
    plt.title('Emissions Quantity by Sector')
    plt.xlabel('Sector')
    plt.ylabel('Emissions Quantity')
    plt.xticks(rotation=45)
    plt.show()
    
    # Emissions by Subsector
    plt.figure(figsize=(12, 6))
    sns.boxplot(data=df, x='subsector', y='emissions_quantity')
    plt.title('Emissions Quantity by Subsector')
    plt.xlabel('Subsector')
    plt.ylabel('Emissions Quantity')
    plt.xticks(rotation=45)
    plt.show()
    
    # Heatmap of emissions quantity by Country and Year
    pivot_table = df.pivot_table(index='iso3_country', columns='Year', values='emissions_quantity', aggfunc='sum')
    plt.figure(figsize=(12, 8))
    sns.heatmap(pivot_table, cmap='YlGnBu', annot=True, fmt='.1f')
    plt.title('Heatmap of Emissions Quantity by Country and Year')
    plt.xlabel('Year')
    plt.ylabel('Country')
    plt.show()

# Run functions
descriptive_statistics(filtered_emission_data)

# %%
# %%
# creating the plots and visuals
data_visualization(filtered_emission_data)


