# %%
# Filename: Statistical_Analysis_nondistinct.py
# Author: Team5: Jan Pierre Lusterio, Lovely Cano, Nicanor Nuqui, Saisuraj Rajesh
# Course: Data_406_CapStone_Project
# Details: This program is formulated to perform descriptive and statistical analyses (nondistinct counting),
# along with plotting the results for each.
#   PRE-REQ: pip install pandas seaborn matplotlib scipy


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import chi2_contingency

# Load the CSV file
file_path = 'Source_Ownership.csv'
data = pd.read_csv(file_path)

# Retain only the specified columns
columns_to_keep = ['source_name', 'iso3_country', 'sector', 'subsector']
filtered_data = data[columns_to_keep]

# Summary statistics for the data
summary_statistics = filtered_data.describe(include='all')
print(summary_statistics)

# Frequency counts for each categorical column
frequency_counts = {
    'source_name': filtered_data['source_name'].value_counts(),
    'iso3_country': filtered_data['iso3_country'].value_counts(),
    'sector': filtered_data['sector'].value_counts(),
    'subsector': filtered_data['subsector'].value_counts(),
}

for col, counts in frequency_counts.items():
    print(f"Frequency counts for {col}:\n{counts}\n")

# Cross-tabulation of iso3_country and sector
cross_tab = pd.crosstab(filtered_data['iso3_country'], filtered_data['sector'])
print(cross_tab.head(10))

# Perform Chi-Square test on the cross-tabulation table
chi2, p, dof, expected = chi2_contingency(cross_tab)
print(f"Chi-Square Test Result: Chi2 = {chi2}, p-value = {p}")

# Plotting frequency counts for each categorical column with color variations
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

sns.countplot(y='source_name', data=filtered_data, order=filtered_data['source_name'].value_counts().index[:10], palette="viridis", ax=axes[0, 0])
axes[0, 0].set_title('Top 10 Source Names')

sns.countplot(y='iso3_country', data=filtered_data, order=filtered_data['iso3_country'].value_counts().index[:10], palette="plasma", ax=axes[0, 1])
axes[0, 1].set_title('Top 10 ISO3 Countries')

sns.countplot(y='sector', data=filtered_data, order=filtered_data['sector'].value_counts().index, palette="inferno", ax=axes[1, 0])
axes[1, 0].set_title('Sector Counts')

sns.countplot(y='subsector', data=filtered_data, order=filtered_data['subsector'].value_counts().index, palette="magma", ax=axes[1, 1])
axes[1, 1].set_title('Subsector Counts')

plt.tight_layout()
plt.show()

# %%
