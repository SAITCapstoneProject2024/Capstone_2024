# %% [markdown]
# 
# Filename: ExponentialSmoothening.ipynb
# 
# Author: Team5: Jan Pierre Lusterio, Lovely Cano, Nicanor Nuqui, Saisuraj Rajesh
# 
# Course: Data_406_CapStone_Project
# 
# Details: This program allows you to trend Co2_100YR gas type historically between 2015 to 2022 and forecast GHG emissions for the next 5 years. Emission count has been aggregated for all Countries, Sector, and Subsector.
# 
# NOTE: adjust the x variable to change the number of years ahead for the forecast.
# 
# PRE-REQ: pip install pandas prophet matplotlib statsmodels sklearn numpy
# 
# Resource: https://stackoverflow.com/questions/50785479/holt-winters-time-series-forecasting-with-statsmodels

# %% [markdown]
# 

# %%
# Import all required Libraries
# pip install statsmodels - if not installed
# pip install hotlwinters - if not installed

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.seasonal import seasonal_decompose
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np


# %%
# Load the dataset provided by Power BI
# df = dataset # for powerbi loading..


# Load the dataset
file_path = "Emission_Dataset.xlsx"  # Load the Excel file

df = pd.read_excel(file_path) # Load the CSV into a DataFrame
df.head()

# %%
#Data Preparation / Cleansing

# Filter the DataFrame to keep only rows where 'gas' is 'co2e_100yr'
df_co2e_100yr = df[df['gas'] == 'co2e_100yr']

# Remove some columns not needed
columns_to_remove = ['start_time', 'end_time', 'emissions_quantity_units', 'temporal_granularity']
df_co2e_100yr.drop(columns=columns_to_remove, inplace=True)

# Remove rows with null or NaN values in the 'emissions_quantity' column
df_co2e_100yr.dropna(subset=['emissions_quantity'], inplace=True)

# Display the first few rows of the filtered DataFrame
df_co2e_100yr.head()

# %%
# Filter the DataFrame to include only the years between 2015 and 2022
df_filtered = df_co2e_100yr[(df_co2e_100yr['Year'] >= 2015) & (df_co2e_100yr['Year'] <= 2022)]

# Group the DataFrame by year and sum the emissions_quantity
df_grouped = df_filtered.groupby('Year')['emissions_quantity'].sum().reset_index()

# %%
# Create a line chart
plt.figure(figsize=(10, 6))
sns.lineplot(data=df_grouped, x='Year', y='emissions_quantity', marker='o')
plt.title('CO2e Emissions Quantity Over Years (2015-2023)')
plt.xlabel('Year')
plt.ylabel('Emissions Quantity')
plt.grid(True)
plt.show()

# %%
df_grouped

# %%
# Convert 'Year' to a datetime index
df_grouped['Year'] = pd.to_datetime(df_grouped['Year'], format='%Y')
df_grouped.set_index('Year', inplace=True)

# %%
df_grouped

# %%
# Performing seasonal decomposition
decomposition = seasonal_decompose(df_grouped['emissions_quantity'], model='add')

# seasonal_decompose(df_grouped).plot()

# Plot the decomposition
plt.figure(figsize=(12, 8))
decomposition.plot()
plt.show()

# %%
# Splitting and Training Model

train = df_grouped.iloc[:6]
test = df_grouped.iloc[6:]

df_grouped.info()

# %%
# Fit the Holt-Winters model
model = ExponentialSmoothing(train['emissions_quantity'], trend='add', seasonal=None, seasonal_periods=7)
fit = model.fit()

# %%
# Make predictions (for example, forecast for the next 5 years)
# forecast_steps = 10
# forecast = fit.forecast(steps=forecast_steps)


# Get model parameters
alpha = fit.params['smoothing_level']  # Alpha (smoothing level)
beta = fit.params['smoothing_trend']   # Beta (smoothing trend)
print(f'Alpha (smoothing level): {alpha}')
print(f'Beta (smoothing trend): {beta}')

# Make predictions
forecast_steps = max(10, len(test))  # Forecast for at least 10 years or the length of the test set
forecast = fit.forecast(steps=forecast_steps)

# Ensure the lengths are consistent for metrics calculation
# Trim forecast to the length of the test set if forecast is longer
forecast_trimmed = forecast[:len(test)]

# %%
# Create a line chart with forecasts
plt.figure(figsize=(12, 6))
plt.plot(df_grouped.index, df_grouped['emissions_quantity'], label='Observed', marker='o')
plt.plot(forecast.index, forecast, label='Forecast', color='red', linestyle='--', marker='o')
plt.title('Holt-Winters Forecast for CO2e Emissions')
plt.xlabel('Year')
plt.ylabel('Emissions Quantity')
plt.legend()
plt.grid(True)
plt.show()

# %%
# Other syntax to fit the Holt-Winters model
plt.figure(figsize =(12,6))
model = ExponentialSmoothing(train,trend='add', seasonal=None, seasonal_periods=7).fit()
df_grouped.plot()
model.forecast(10).plot(figsize = (12,6))

# %%
# Calculate evaluation metrics
mae = mean_absolute_error(test['emissions_quantity'], forecast_trimmed)
mse = mean_squared_error(test['emissions_quantity'], forecast_trimmed)
rmse = np.sqrt(mse)
mape = np.mean(np.abs((test['emissions_quantity'] - forecast_trimmed) / test['emissions_quantity'])) * 100
r_squared = 1 - (np.sum((test['emissions_quantity'] - forecast_trimmed) ** 2) / np.sum((test['emissions_quantity'] - np.mean(test['emissions_quantity'])) ** 2))

print(f'Mean Absolute Error (MAE): {mae}')
print(f'Mean Squared Error (MSE): {mse}')
print(f'Root Mean Squared Error (RMSE): {rmse}')
print(f'Mean Absolute Percentage Error (MAPE): {mape}%')
print(f'R-squared (R²): {r_squared}')


